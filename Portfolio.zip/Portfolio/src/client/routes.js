import Home from './components/DashboardComponent';

const routes = [
  {
    path: "/",
    exact: true,
    component: Home
  }
];

export default routes;